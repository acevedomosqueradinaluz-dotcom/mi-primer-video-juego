import pygame
import sys
import random

# Inicializar Pygame y su mezclador de audio
pygame.init()
pygame.mixer.init()

# Configuración de la pantalla
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Mi Videojuego Arcade")

# Colores
NEGRO = (0, 0, 0)
BLANCO = (255, 255, 255)
VERDE = (0, 255, 0)
ROJO = (255, 0, 0)
AZUL_FONDO = (30, 40, 60)
AMARILLO = (255, 215, 0)

# Reloj para controlar los FPS
clock = pygame.time.Clock()
FPS = 60

# Estados del juego
ESTADO_MENU = "menu"
ESTADO_JUEGO = "juego"
ESTADO_FINAL = "final"
estado_actual = ESTADO_MENU

# Variables del jugador y juego
player_pos = [SCREEN_WIDTH // 2, SCREEN_HEIGHT - 70]
player_size = 50
player_speed = 8

# Obstáculos (Rojos) y Objetivos (Verdes)
obstacle_size = 50
obstacle_pos = [random.randint(0, SCREEN_WIDTH - obstacle_size), 0]
obstacle_speed = 7

objective_size = 40
objective_pos = [random.randint(0, SCREEN_WIDTH - objective_size), 0]
objective_speed = 5

puntuacion = 0
resultado_texto = ""

# Intentar generar sonidos sintéticos simples en caso de no tener archivos de audio externos
def generar_sonido_tono(frecuencia, duracion_ms):
    try:
        import numpy as np
        sample_rate = 44100
        n_samples = int(sample_rate * (duracion_ms / 1000.0))
        t = np.linspace(0, duracion_ms / 1000.0, n_samples, endpoint=False)
        data = np.sin(2 * np.pi * frecuencia * t)
        # Convertir a 16-bit PCM
        audio_data = (data * 32767).astype(np.int16)
        # Duplicar para estéreo si es necesario, o mantener mono
        sound_buffer = np.repeat(audio_data[:, np.newaxis], 2, axis=1) if len(audio_data.shape) == 1 else audio_data
        return pygame.sndarray.make_sound(sound_buffer)
    except:
        return None

# Intentar crear los efectos de sonido de victoria y derrota
sonido_gano = generar_sonido_tono(523.25, 400)  # Nota Do5 para ganar
sonido_perdio = generar_sonido_tono(130.81, 400) # Nota Do3 para perder

def reproducir_sonido(gano):
    if gano and sonido_gano:
        sonido_gano.play()
    elif not gano and sonido_perdio:
        sonido_perdio.play()

# Fuentes
font_grande = pygame.font.SysFont("Arial", 50, bold=True)
font_mediana = pygame.font.SysFont("Arial", 30)

def dibujar_texto(texto, fuente, color, x, y):
    superficie = fuente.render(texto, True, color)
    rectangulo = superficie.get_rect(center=(x, y))
    screen.blit(superficie, rectangulo)

# Bucle principal del juego
running = True
while running:
    # Dibujar Fondo base
    screen.fill(AZUL_FONDO)
    
    # Manejo de eventos
    for event in pygame.get_event_loop().get():
        if event.type == pygame.QUIT:
            running = False
            
        if event.type == pygame.KEYDOWN:
            if estado_actual == ESTADO_MENU:
                if event.key == pygame.K_RETURN: # Presionar Enter para empezar
                    estado_actual = ESTADO_JUEGO
                    puntuacion = 0
                    player_pos = [SCREEN_WIDTH // 2, SCREEN_HEIGHT - 70]
                    obstacle_pos = [random.randint(0, SCREEN_WIDTH - obstacle_size), 0]
                    objective_pos = [random.randint(0, SCREEN_WIDTH - objective_size), 0]
                    
            elif estado_actual == ESTADO_FINAL:
                if event.key == pygame.K_r: # Presionar R para reiniciar al menú
                    estado_actual = ESTADO_MENU

    # Lógica de estados
    if estado_actual == ESTADO_MENU:
        dibujar_texto("BIENVENIDO AL JUEGO", font_grande, AMARILLO, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 3)
        dibujar_texto("Instrucciones: Esquiva los bloques ROJOS y atrapa los VERDES.", font_mediana, BLANCO, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        dibujar_texto("¡Llega a 5 puntos para GANAR!", font_mediana, VERDE, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 40)
        dibujar_texto("Presiona [ENTER] para Iniciar", font_grande, BLANCO, SCREEN_WIDTH // 2, SCREEN_HEIGHT * 3 // 4)
        
    elif estado_actual == ESTADO_JUEGO:
        # Controles del jugador (Movimiento horizontal)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_pos[0] > 0:
            player_pos[0] -= player_speed
        if keys[pygame.K_RIGHT] and player_pos[0] < SCREEN_WIDTH - player_size:
            player_pos[0] += player_speed

        # Actualizar posición de caída de los objetos
        obstacle_pos[1] += obstacle_speed
        objective_pos[1] += objective_speed

        # Si el obstáculo sale de la pantalla, reaparece arriba
        if obstacle_pos[1] > SCREEN_HEIGHT:
            obstacle_pos = [random.randint(0, SCREEN_WIDTH - obstacle_size), 0]
            
        # Si el objetivo sale de la pantalla, reaparece arriba
        if objective_pos[1] > SCREEN_HEIGHT:
            objective_pos = [random.randint(0, SCREEN_WIDTH - objective_size), 0]

        # Crear rectángulos de colisión
        player_rect = pygame.Rect(player_pos[0], player_pos[1], player_size, player_size)
        obstacle_rect = pygame.Rect(obstacle_pos[0], obstacle_pos[1], obstacle_size, obstacle_size)
        objective_rect = pygame.Rect(objective_pos[0], objective_pos[1], objective_size, objective_size)

        # Colisión con Obstáculo (Derrota)
        if player_rect.colliderect(obstacle_rect):
            resultado_texto = "¡PERDISTE!"
            reproducir_sonido(gano=False)
            estado_actual = ESTADO_FINAL

        # Colisión con Objetivo (Punto)
        if player_rect.colliderect(objective_rect):
            puntuacion += 1
            objective_pos = [random.randint(0, SCREEN_WIDTH - objective_size), 0]
            # Condición de Victoria
            if puntuacion >= 5:
                resultado_texto = "¡GANASTE!"
                reproducir_sonido(gano=True)
                estado_actual = ESTADO_FINAL

        # Dibujar elementos en pantalla
        pygame.draw.rect(screen, BLANCO, player_rect) # Jugador
        pygame.draw.rect(screen, ROJO, obstacle_rect) # Obstáculo
        pygame.draw.rect(screen, VERDE, objective_rect) # Objetivo
        
        # Mostrar puntuación actual
        dibujar_texto(f"Puntos: {puntuacion}", font_mediana, BLANCO, 80, 30)

    elif estado_actual == ESTADO_FINAL:
        color_resultado = VERDE if "GANASTE" in resultado_texto else ROJO
        dibujar_texto(resultado_texto, font_grande, color_resultado, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 3)
        dibujar_texto(f"Puntuación final: {puntuacion}", font_mediana, BLANCO, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        dibujar_texto("Presiona [R] para volver al menú de entrada", font_mediana, AMARILLO, SCREEN_WIDTH // 2, SCREEN_HEIGHT * 2 // 3)

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
sys.exit()
