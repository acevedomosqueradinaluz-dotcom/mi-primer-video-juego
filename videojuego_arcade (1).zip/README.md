# Mi Videojuego Arcade en Python

Este proyecto es un videojuego base estructurado en Python listo para ser ejecutado localmente desde tu computador usando **Visual Studio Code** y subirse directamente a **GitHub**.

## 🚀 Requisitos e Instalación

1. Asegúrate de tener Python instalado en tu computador.
2. Abre la carpeta del proyecto en Visual Studio Code.
3. Abre una terminal en VS Code e instala las librerías necesarias con el siguiente comando:
   ```bash
   pip install pygame numpy
   ```

## 🎮 Cómo Jugar
- **Pantalla de Entrada:** Presiona la tecla `ENTER` para arrancar la partida.
- **Controles:** Usa las flechas direccionales izquierda (`←`) y derecha (`→`) para mover tu bloque blanco.
- **Reglas:** 
  - Atrapa los bloques **Verdes** para sumar puntos.
  - Esquiva los bloques **Rojos**. Si te toca uno, pierdes de inmediato.
  - ¡Alcanza **5 puntos** para ganar!
- **Efectos de Audio:** El juego genera frecuencias de sonido de manera sintética avisando mediante tonos agudos si se gana o graves si se pierde.

## 📦 Subir a GitHub
Ejecuta estos comandos en tu terminal de VS Code:
```bash
git init
git add .
git commit -m "Primer commit: Estructura del videojuego"
git branch -M main
git remote add origin TU_URL_DE_REPOSITORIO_DE_GITHUB
git push -u origin main
```
